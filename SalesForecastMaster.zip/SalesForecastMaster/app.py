import streamlit as st
import pandas as pd
import numpy as np
import datetime
import os
from utils.data_processor import DataProcessor
from utils.model_trainer import ModelTrainer
from utils.visualization import plot_time_series, plot_feature_importance, plot_model_comparison

# Set page configuration
st.set_page_config(
    page_title="Sales Forecasting Application",
    page_icon="📈",
    layout="wide"
)

# Initialize session state variables
if 'data' not in st.session_state:
    st.session_state.data = None
if 'models' not in st.session_state:
    st.session_state.models = {}
if 'predictions' not in st.session_state:
    st.session_state.predictions = {}
if 'metrics' not in st.session_state:
    st.session_state.metrics = {}
if 'selected_features' not in st.session_state:
    st.session_state.selected_features = []
if 'target_column' not in st.session_state:
    st.session_state.target_column = None

# Main page header
st.title("📈 Sales Forecasting Application")
st.markdown("### Predict your sales with advanced ML models")

# Sidebar with navigation
st.sidebar.title("Navigation")
page = st.sidebar.radio(
    "Go to",
    ["Data Upload", "Feature Engineering", "Model Training", "Model Comparison"]
)

# Data upload section
if page == "Data Upload":
    st.header("Data Upload")
    st.info("Upload your historical sales data in CSV format to begin the forecasting process.")
    
    uploaded_file = st.file_uploader("Choose a CSV file", type="csv")
    
    if uploaded_file is not None:
        try:
            # Load and display the data
            data = pd.read_csv(uploaded_file)
            st.session_state.data = data
            
            st.success("Data uploaded successfully!")
            st.write("Preview of your data:")
            st.dataframe(data.head())
            
            # Display basic statistics
            st.subheader("Data Statistics")
            st.write(data.describe())
            
            # Check for date column
            date_columns = [col for col in data.columns if 'date' in col.lower() or 'time' in col.lower()]
            if date_columns:
                st.info(f"Detected potential date columns: {', '.join(date_columns)}")
            
            # Let user select date column and target column
            all_cols = list(data.columns)
            date_col = st.selectbox(
                "Select your date column", 
                options=all_cols,
                index=date_columns.index(date_columns[0]) if date_columns else 0
            )
            
            target_col = st.selectbox(
                "Select your target column (sales to predict)",
                options=[col for col in all_cols if col != date_col]
            )
            
            if st.button("Prepare Data"):
                # Initialize data processor
                data_processor = DataProcessor()
                
                # Process the data
                processed_data = data_processor.preprocess_data(data, date_col, target_col)
                st.session_state.data = processed_data
                st.session_state.target_column = target_col
                
                # Show processed data
                st.success("Data processed successfully!")
                st.write("Processed data preview:")
                st.dataframe(processed_data.head())
                
                # Suggest available features for model training
                available_features = [col for col in processed_data.columns if col != target_col]
                st.session_state.selected_features = available_features
                
                st.info("You can now move to Feature Engineering to select and transform your features.")
        
        except Exception as e:
            st.error(f"Error: {e}")
            st.error("Please ensure your CSV file is correctly formatted.")

# Render feature engineering page if selected
elif page == "Feature Engineering":
    # Import and run feature engineering page
    from pages.feature_engineering import render_feature_engineering
    render_feature_engineering()

# Render model training page if selected
elif page == "Model Training":
    # Import and run model training page
    from pages.model_training import render_model_training
    render_model_training()

# Render model comparison page if selected
elif page == "Model Comparison":
    # Import and run model comparison page
    from pages.model_comparison import render_model_comparison
    render_model_comparison()

# Footer
st.sidebar.markdown("---")
st.sidebar.markdown("### About")
st.sidebar.info(
    "This application provides ML-powered sales forecasting with multiple models, "
    "interactive visualizations, and custom dataset training capabilities."
)
