import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import xgboost as xgb
from prophet import Prophet
from statsmodels.tsa.arima.model import ARIMA
from datetime import datetime, timedelta
import os
import joblib

# Try importing TensorFlow, but make it optional
try:
    import tensorflow as tf
    TENSORFLOW_AVAILABLE = True
except (ImportError, TypeError, AttributeError) as e:
    TENSORFLOW_AVAILABLE = False
    print(f"TensorFlow not available: {e}. LSTM model will be disabled.")

class ModelTrainer:
    def __init__(self):
        """Initialize model trainer with available models"""
        self.models = {
            'Linear Regression': None,
            'Random Forest': None,
            'XGBoost': None,
            'Prophet': None,
            'LSTM': None
        }
        self.metrics = {}
        self.feature_importance = {}
        
    def train_linear_regression(self, X_train, y_train):
        """
        Train a Linear Regression model
        
        Parameters:
        -----------
        X_train : numpy array
            Training features
        y_train : numpy array
            Training target values
            
        Returns:
        --------
        sklearn.linear_model.LinearRegression
            Trained linear regression model
        """
        model = LinearRegression()
        model.fit(X_train, y_train)
        self.models['Linear Regression'] = model
        return model
    
    def train_random_forest(self, X_train, y_train, n_estimators=100, max_depth=None):
        """
        Train a Random Forest Regressor model
        
        Parameters:
        -----------
        X_train : numpy array
            Training features
        y_train : numpy array
            Training target values
        n_estimators : int
            Number of trees in the forest
        max_depth : int or None
            Maximum depth of the trees
            
        Returns:
        --------
        sklearn.ensemble.RandomForestRegressor
            Trained random forest model
        """
        model = RandomForestRegressor(n_estimators=n_estimators, max_depth=max_depth, random_state=42)
        model.fit(X_train, y_train)
        self.models['Random Forest'] = model
        return model
    
    def train_xgboost(self, X_train, y_train, n_estimators=100, learning_rate=0.1, max_depth=6):
        """
        Train an XGBoost model
        
        Parameters:
        -----------
        X_train : numpy array
            Training features
        y_train : numpy array
            Training target values
        n_estimators : int
            Number of boosting rounds
        learning_rate : float
            Learning rate
        max_depth : int
            Maximum tree depth
            
        Returns:
        --------
        xgboost.XGBRegressor
            Trained XGBoost model
        """
        model = xgb.XGBRegressor(
            n_estimators=n_estimators,
            learning_rate=learning_rate,
            max_depth=max_depth,
            random_state=42
        )
        model.fit(X_train, y_train)
        self.models['XGBoost'] = model
        return model
    
    def train_prophet(self, df_prophet, seasonality_mode='additive', yearly_seasonality=True, weekly_seasonality=True):
        """
        Train a Prophet model
        
        Parameters:
        -----------
        df_prophet : pandas DataFrame
            Data formatted for Prophet with 'ds' and 'y' columns
        seasonality_mode : str
            Either 'additive' or 'multiplicative'
        yearly_seasonality : bool or int
            Whether to fit yearly seasonality
        weekly_seasonality : bool or int
            Whether to fit weekly seasonality
            
        Returns:
        --------
        prophet.Prophet
            Trained Prophet model
        """
        model = Prophet(
            seasonality_mode=seasonality_mode,
            yearly_seasonality=yearly_seasonality,
            weekly_seasonality=weekly_seasonality
        )
        model.fit(df_prophet)
        self.models['Prophet'] = model
        return model
    
    def train_lstm(self, X_train, y_train, epochs=50, batch_size=32):
        """
        Train an LSTM model
        
        Parameters:
        -----------
        X_train : numpy array
            Training features shaped for LSTM (samples, time steps, features)
        y_train : numpy array
            Training target values
        epochs : int
            Number of training epochs
        batch_size : int
            Batch size for training
            
        Returns:
        --------
        tensorflow.keras.Model
            Trained LSTM model or None if TensorFlow is not available
        """
        if not TENSORFLOW_AVAILABLE:
            print("TensorFlow is not available. LSTM model cannot be trained.")
            return None
            
        # Define LSTM model
        model = tf.keras.models.Sequential([
            tf.keras.layers.LSTM(50, return_sequences=True, input_shape=(X_train.shape[1], X_train.shape[2])),
            tf.keras.layers.LSTM(50),
            tf.keras.layers.Dense(1)
        ])
        
        # Compile the model
        model.compile(optimizer='adam', loss='mse')
        
        # Train the model
        model.fit(
            X_train, y_train,
            epochs=epochs,
            batch_size=batch_size,
            verbose=0
        )
        
        self.models['LSTM'] = model
        return model
    
    def evaluate_model(self, model_name, X_test, y_test):
        """
        Evaluate a trained model
        
        Parameters:
        -----------
        model_name : str
            Name of the model to evaluate
        X_test : numpy array
            Testing features
        y_test : numpy array
            Testing target values
            
        Returns:
        --------
        dict
            Dictionary of evaluation metrics
        """
        model = self.models[model_name]
        
        if model is None:
            raise ValueError(f"Model {model_name} has not been trained yet.")
        
        # Make predictions
        y_pred = model.predict(X_test)
        
        # Calculate metrics
        metrics = {
            'MSE': mean_squared_error(y_test, y_pred),
            'RMSE': np.sqrt(mean_squared_error(y_test, y_pred)),
            'MAE': mean_absolute_error(y_test, y_pred),
            'R2': r2_score(y_test, y_pred)
        }
        
        self.metrics[model_name] = metrics
        return metrics
    
    def evaluate_prophet(self, model, df_test):
        """
        Evaluate a Prophet model
        
        Parameters:
        -----------
        model : prophet.Prophet
            Trained Prophet model
        df_test : pandas DataFrame
            Testing data with 'ds' column
            
        Returns:
        --------
        dict
            Dictionary of evaluation metrics
        """
        # Make future dataframe for prediction
        future = df_test[['ds']].copy()
        
        # Make predictions
        forecast = model.predict(future)
        
        # Extract predicted values
        y_pred = forecast['yhat'].values
        y_test = df_test['y'].values
        
        # Calculate metrics
        metrics = {
            'MSE': mean_squared_error(y_test, y_pred),
            'RMSE': np.sqrt(mean_squared_error(y_test, y_pred)),
            'MAE': mean_absolute_error(y_test, y_pred),
            'R2': r2_score(y_test, y_pred)
        }
        
        self.metrics['Prophet'] = metrics
        return metrics, forecast
    
    def evaluate_lstm(self, model, X_test, y_test):
        """
        Evaluate an LSTM model
        
        Parameters:
        -----------
        model : tensorflow.keras.Model
            Trained LSTM model
        X_test : numpy array
            Testing features shaped for LSTM
        y_test : numpy array
            Testing target values
            
        Returns:
        --------
        dict
            Dictionary of evaluation metrics
        """
        if not TENSORFLOW_AVAILABLE or model is None:
            print("TensorFlow is not available or model is None. Cannot evaluate LSTM model.")
            return None
            
        # Make predictions
        y_pred = model.predict(X_test).flatten()
        
        # Calculate metrics
        metrics = {
            'MSE': mean_squared_error(y_test, y_pred),
            'RMSE': np.sqrt(mean_squared_error(y_test, y_pred)),
            'MAE': mean_absolute_error(y_test, y_pred),
            'R2': r2_score(y_test, y_pred)
        }
        
        self.metrics['LSTM'] = metrics
        return metrics
    
    def get_feature_importance(self, model_name, feature_names):
        """
        Get feature importance from a trained model
        
        Parameters:
        -----------
        model_name : str
            Name of the model
        feature_names : list
            List of feature names
            
        Returns:
        --------
        pandas DataFrame
            DataFrame with feature importance values or None if not applicable
        """
        model = self.models.get(model_name)
        
        if model is None:
            print(f"Model {model_name} is not trained yet.")
            return None
            
        if model_name == 'Linear Regression':
            try:
                importance = np.abs(model.coef_)
            except (AttributeError, TypeError) as e:
                print(f"Could not get coefficients from Linear Regression model: {e}")
                return None
        elif model_name in ['Random Forest', 'XGBoost']:
            try:
                importance = model.feature_importances_
            except (AttributeError, TypeError) as e:
                print(f"Could not get feature importances from {model_name} model: {e}")
                return None
        else:
            return None  # Not applicable for Prophet or LSTM
        
        # Create DataFrame with feature importance
        importance_df = pd.DataFrame({
            'Feature': feature_names,
            'Importance': importance
        })
        
        # Sort by importance
        importance_df = importance_df.sort_values('Importance', ascending=False)
        
        self.feature_importance[model_name] = importance_df
        return importance_df
    
    def forecast_future(self, model_name, X_future, steps=30):
        """
        Generate future forecasts
        
        Parameters:
        -----------
        model_name : str
            Name of the model to use for forecasting
        X_future : numpy array or pandas DataFrame
            Future features or starting point for forecast
        steps : int
            Number of steps to forecast
            
        Returns:
        --------
        numpy array
            Forecasted values or None if model is not available
        """
        model = self.models.get(model_name)
        
        if model is None:
            print(f"Model {model_name} is not trained yet.")
            return None
            
        try:
            if model_name in ['Linear Regression', 'Random Forest', 'XGBoost']:
                return model.predict(X_future)
        except Exception as e:
            print(f"Error making predictions with {model_name}: {e}")
            return None
        
        # For more complex models like LSTM or Prophet, implement specific forecasting logic
        # based on your application requirements
        
        return None
    
    def forecast_prophet(self, model, periods=30, freq='D', include_history=True):
        """
        Generate forecasts with Prophet
        
        Parameters:
        -----------
        model : prophet.Prophet
            Trained Prophet model
        periods : int
            Number of periods to forecast
        freq : str
            Frequency of forecasts (D=daily, W=weekly, etc.)
        include_history : bool
            Whether to include historical data in the forecast
            
        Returns:
        --------
        pandas DataFrame
            Forecast including predictions and confidence intervals
        """
        future = model.make_future_dataframe(periods=periods, freq=freq, include_history=include_history)
        forecast = model.predict(future)
        return forecast
    
    def recursive_forecast_lstm(self, model, last_sequence, steps=30):
        """
        Generate recursive forecasts with LSTM
        
        Parameters:
        -----------
        model : tensorflow.keras.Model
            Trained LSTM model
        last_sequence : numpy array
            Last sequence from the training data
        steps : int
            Number of steps to forecast
            
        Returns:
        --------
        numpy array
            Forecasted values
        """
        if not TENSORFLOW_AVAILABLE or model is None:
            print("TensorFlow is not available or model is None. Cannot generate LSTM forecast.")
            return None
            
        # Clone the last sequence
        curr_seq = last_sequence.copy()
        
        # Container for predictions
        predictions = []
        
        # Recursively predict each step
        for _ in range(steps):
            # Reshape for prediction (samples, time steps, features)
            input_seq = curr_seq.reshape(1, curr_seq.shape[0], curr_seq.shape[1])
            
            # Predict next value
            next_val = model.predict(input_seq)[0, 0]
            
            # Add prediction to the list
            predictions.append(next_val)
            
            # Update sequence by removing the first element and adding the prediction
            curr_seq = np.roll(curr_seq, -1, axis=0)
            curr_seq[-1, 0] = next_val
        
        return np.array(predictions)
