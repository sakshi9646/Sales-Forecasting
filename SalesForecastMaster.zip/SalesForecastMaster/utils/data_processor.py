import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.impute import SimpleImputer

class DataProcessor:
    def __init__(self):
        """Initialize data processor class with necessary transformers"""
        self.numerical_imputer = SimpleImputer(strategy='mean')
        self.categorical_imputer = SimpleImputer(strategy='most_frequent')
        self.scaler = StandardScaler()
        self.encoders = {}
        
    def preprocess_data(self, data, date_column, target_column):
        """
        Preprocess the data for model training
        
        Parameters:
        -----------
        data : pandas DataFrame
            The input sales data
        date_column : str
            The name of the date column
        target_column : str
            The name of the target column to predict
            
        Returns:
        --------
        pandas DataFrame
            Preprocessed data
        """
        # Make a copy to avoid modifying the original data
        df = data.copy()
        
        # Convert date column to datetime
        try:
            df[date_column] = pd.to_datetime(df[date_column])
        except Exception as e:
            raise ValueError(f"Could not convert {date_column} to datetime: {e}")
            
        # Set date as index
        df = df.set_index(date_column)
        
        # Sort by date
        df = df.sort_index()
        
        # Extract date features
        df['year'] = df.index.year
        df['month'] = df.index.month
        df['day'] = df.index.day
        df['day_of_week'] = df.index.dayofweek
        df['quarter'] = df.index.quarter
        
        # Add seasonal features
        df['is_month_start'] = df.index.is_month_start.astype(int)
        df['is_month_end'] = df.index.is_month_end.astype(int)
        df['is_quarter_start'] = df.index.is_quarter_start.astype(int)
        df['is_quarter_end'] = df.index.is_quarter_end.astype(int)
        
        # Add seasonality indicators based on month
        seasons = {
            1: 'Winter', 2: 'Winter', 3: 'Spring',
            4: 'Spring', 5: 'Spring', 6: 'Summer',
            7: 'Summer', 8: 'Summer', 9: 'Fall',
            10: 'Fall', 11: 'Fall', 12: 'Winter'
        }
        df['season'] = df['month'].map(seasons)
        
        # Handle missing values
        for col in df.columns:
            if col == target_column:
                # For target column, we can't impute future values in a forecasting task
                # Just drop NA for now
                df = df.dropna(subset=[target_column])
            elif df[col].dtype.kind in 'ifc':  # numeric columns
                # Impute numeric columns
                df[col] = self.numerical_imputer.fit_transform(df[[col]])
            elif df[col].dtype == 'object' or df[col].dtype == 'category':
                # Impute categorical columns
                df[col] = self.categorical_imputer.fit_transform(df[[col]])
        
        # Add lag features for the target
        for lag in [1, 7, 14, 28]:  # common lags for sales data
            lag_col = f'{target_column}_lag_{lag}'
            df[lag_col] = df[target_column].shift(lag)
        
        # Add rolling mean and std
        for window in [7, 14, 30]:
            df[f'{target_column}_rolling_mean_{window}'] = df[target_column].rolling(window=window).mean()
            df[f'{target_column}_rolling_std_{window}'] = df[target_column].rolling(window=window).std()
        
        # Drop rows with NaN values created by lag and rolling features
        df = df.dropna()
        
        return df
    
    def train_test_split(self, data, test_size=0.2):
        """
        Split the data into training and testing sets based on time
        
        Parameters:
        -----------
        data : pandas DataFrame
            The preprocessed data
        test_size : float
            The proportion of the data to use for testing
            
        Returns:
        --------
        tuple
            (X_train, X_test, y_train, y_test)
        """
        # Calculate the split point
        split_idx = int(len(data) * (1 - test_size))
        
        # Split the data
        train_data = data.iloc[:split_idx]
        test_data = data.iloc[split_idx:]
        
        return train_data, test_data
    
    def prepare_features_targets(self, data, target_column, features):
        """
        Prepare feature and target arrays
        
        Parameters:
        -----------
        data : pandas DataFrame
            The preprocessed data
        target_column : str
            The name of the target column
        features : list
            List of feature columns to use
            
        Returns:
        --------
        tuple
            (X, y) where X is a numpy array of features and y is a numpy array of targets
        """
        X = data[features].values
        y = data[target_column].values
        
        return X, y
    
    def scale_features(self, X_train, X_test):
        """
        Scale numerical features
        
        Parameters:
        -----------
        X_train : numpy array
            Training features
        X_test : numpy array
            Testing features
            
        Returns:
        --------
        tuple
            (X_train_scaled, X_test_scaled)
        """
        # Fit scaler on training data and transform both training and test data
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)
        
        return X_train_scaled, X_test_scaled
    
    def encode_categorical(self, data, categorical_columns):
        """
        Encode categorical features using one-hot encoding
        
        Parameters:
        -----------
        data : pandas DataFrame
            The data containing categorical columns
        categorical_columns : list
            List of categorical column names
            
        Returns:
        --------
        pandas DataFrame
            Data with categorical columns encoded
        """
        df = data.copy()
        
        for col in categorical_columns:
            # Create encoder if it doesn't exist
            if col not in self.encoders:
                self.encoders[col] = OneHotEncoder(sparse=False, handle_unknown='ignore')
                # Fit the encoder
                self.encoders[col].fit(df[[col]])
            
            # Transform the column
            encoded = self.encoders[col].transform(df[[col]])
            
            # Get the column names
            categories = self.encoders[col].categories_[0]
            encoded_cols = [f"{col}_{cat}" for cat in categories]
            
            # Add encoded columns to dataframe
            encoded_df = pd.DataFrame(encoded, columns=encoded_cols, index=df.index)
            df = pd.concat([df, encoded_df], axis=1)
            
            # Drop original column
            df = df.drop(col, axis=1)
        
        return df
    
    def prepare_for_prophet(self, data, date_column, target_column):
        """
        Prepare data specifically for Prophet model
        
        Parameters:
        -----------
        data : pandas DataFrame
            The original data
        date_column : str
            The name of the date column
        target_column : str
            The name of the target column
            
        Returns:
        --------
        pandas DataFrame
            Data formatted for Prophet (with 'ds' and 'y' columns)
        """
        # Make a copy of the data
        df = data.copy()
        
        # Ensure date column is in datetime format
        df[date_column] = pd.to_datetime(df[date_column])
        
        # Rename columns for Prophet
        prophet_df = df[[date_column, target_column]].copy()
        prophet_df.columns = ['ds', 'y']
        
        return prophet_df
    
    def prepare_for_lstm(self, data, target_column, sequence_length=30):
        """
        Prepare data for LSTM model by creating sequences
        
        Parameters:
        -----------
        data : pandas DataFrame
            The preprocessed data
        target_column : str
            The name of the target column
        sequence_length : int
            Length of sequences for LSTM
            
        Returns:
        --------
        tuple
            (X, y) where X is a 3D array of sequences and y is the target values
        """
        # Extract target series
        series = data[target_column].values
        
        # Create sequences
        X, y = [], []
        for i in range(len(series) - sequence_length):
            X.append(series[i:i + sequence_length])
            y.append(series[i + sequence_length])
        
        # Convert to numpy arrays
        X = np.array(X)
        y = np.array(y)
        
        # Reshape for LSTM [samples, time steps, features]
        X = X.reshape(X.shape[0], X.shape[1], 1)
        
        return X, y
