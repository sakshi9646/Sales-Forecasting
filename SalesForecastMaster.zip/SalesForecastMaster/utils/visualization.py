import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import matplotlib.pyplot as plt
import seaborn as sns
import streamlit as st

def plot_time_series(data, date_column, target_column, title="Time Series Data"):
    """
    Create an interactive time series plot using Plotly
    
    Parameters:
    -----------
    data : pandas DataFrame
        The data containing date and target columns
    date_column : str
        The name of the date column
    target_column : str
        The name of the target column
    title : str
        The title of the plot
        
    Returns:
    --------
    plotly.graph_objects.Figure
        The plotly figure object
    """
    fig = px.line(
        data, 
        x=date_column, 
        y=target_column,
        title=title
    )
    
    # Add range slider and selector
    fig.update_layout(
        xaxis=dict(
            rangeselector=dict(
                buttons=list([
                    dict(count=1, label="1m", step="month", stepmode="backward"),
                    dict(count=6, label="6m", step="month", stepmode="backward"),
                    dict(count=1, label="YTD", step="year", stepmode="todate"),
                    dict(count=1, label="1y", step="year", stepmode="backward"),
                    dict(step="all")
                ])
            ),
            rangeslider=dict(visible=True),
            type="date"
        )
    )
    
    return fig

def plot_feature_importance(importance_df, title="Feature Importance"):
    """
    Create a bar chart of feature importance
    
    Parameters:
    -----------
    importance_df : pandas DataFrame
        DataFrame with 'Feature' and 'Importance' columns
    title : str
        The title of the plot
        
    Returns:
    --------
    plotly.graph_objects.Figure
        The plotly figure object
    """
    # Sort by importance
    df = importance_df.sort_values('Importance')
    
    fig = px.bar(
        df,
        x='Importance',
        y='Feature',
        orientation='h',
        title=title
    )
    
    fig.update_layout(
        yaxis={'categoryorder': 'total ascending'},
        xaxis_title="Importance",
        yaxis_title="Feature"
    )
    
    return fig

def plot_actual_vs_predicted(y_true, y_pred, dates=None, title="Actual vs Predicted"):
    """
    Create a line plot comparing actual and predicted values
    
    Parameters:
    -----------
    y_true : array-like
        The actual values
    y_pred : array-like
        The predicted values
    dates : array-like, optional
        The dates for the x-axis
    title : str
        The title of the plot
        
    Returns:
    --------
    plotly.graph_objects.Figure
        The plotly figure object
    """
    # Create DataFrame for plotting
    if dates is None:
        df = pd.DataFrame({
            'Actual': y_true,
            'Predicted': y_pred
        })
    else:
        df = pd.DataFrame({
            'Date': dates,
            'Actual': y_true,
            'Predicted': y_pred
        })
    
    # Create figure
    fig = go.Figure()
    
    # Add traces
    if dates is None:
        fig.add_trace(go.Scatter(y=df['Actual'], mode='lines', name='Actual'))
        fig.add_trace(go.Scatter(y=df['Predicted'], mode='lines', name='Predicted'))
    else:
        fig.add_trace(go.Scatter(x=df['Date'], y=df['Actual'], mode='lines', name='Actual'))
        fig.add_trace(go.Scatter(x=df['Date'], y=df['Predicted'], mode='lines', name='Predicted'))
    
    # Update layout
    fig.update_layout(
        title=title,
        xaxis_title="Date" if dates is not None else "Index",
        yaxis_title="Value",
        legend=dict(x=0.01, y=0.99),
        hovermode="x unified"
    )
    
    return fig

def plot_forecast_with_confidence(forecast, title="Forecast with Confidence Intervals"):
    """
    Create a plot for Prophet forecasts with confidence intervals
    
    Parameters:
    -----------
    forecast : pandas DataFrame
        The Prophet forecast DataFrame
    title : str
        The title of the plot
        
    Returns:
    --------
    plotly.graph_objects.Figure
        The plotly figure object
    """
    fig = go.Figure()
    
    # Add the forecast line
    fig.add_trace(go.Scatter(
        x=forecast['ds'],
        y=forecast['yhat'],
        mode='lines',
        name='Forecast',
        line=dict(color='blue')
    ))
    
    # Add the upper bound
    fig.add_trace(go.Scatter(
        x=forecast['ds'],
        y=forecast['yhat_upper'],
        mode='lines',
        name='Upper Bound (95%)',
        line=dict(width=0),
        showlegend=False
    ))
    
    # Add the lower bound
    fig.add_trace(go.Scatter(
        x=forecast['ds'],
        y=forecast['yhat_lower'],
        mode='lines',
        name='Lower Bound (95%)',
        line=dict(width=0),
        fill='tonexty',
        fillcolor='rgba(0, 176, 246, 0.2)',
        showlegend=False
    ))
    
    # Update layout
    fig.update_layout(
        title=title,
        xaxis_title="Date",
        yaxis_title="Value",
        legend=dict(x=0.01, y=0.99),
        hovermode="x unified"
    )
    
    # Add range slider
    fig.update_layout(
        xaxis=dict(
            rangeselector=dict(
                buttons=list([
                    dict(count=1, label="1m", step="month", stepmode="backward"),
                    dict(count=6, label="6m", step="month", stepmode="backward"),
                    dict(count=1, label="YTD", step="year", stepmode="todate"),
                    dict(count=1, label="1y", step="year", stepmode="backward"),
                    dict(step="all")
                ])
            ),
            rangeslider=dict(visible=True),
            type="date"
        )
    )
    
    return fig

def plot_model_comparison(metrics_dict, metric_name='RMSE'):
    """
    Create a bar chart comparing different models on a specific metric
    
    Parameters:
    -----------
    metrics_dict : dict
        Dictionary with model names as keys and metric dictionaries as values
    metric_name : str
        The name of the metric to compare
        
    Returns:
    --------
    plotly.graph_objects.Figure
        The plotly figure object
    """
    models = []
    values = []
    
    for model_name, metrics in metrics_dict.items():
        if metric_name in metrics:
            models.append(model_name)
            values.append(metrics[metric_name])
    
    # Create DataFrame for plotting
    df = pd.DataFrame({
        'Model': models,
        metric_name: values
    })
    
    # Sort by metric value (lower is better for most metrics)
    df = df.sort_values(metric_name)
    
    # Create bar chart
    fig = px.bar(
        df,
        x='Model',
        y=metric_name,
        title=f'Model Comparison - {metric_name}',
        color='Model'
    )
    
    return fig

def plot_multiple_metrics(metrics_dict, metrics_to_plot=None):
    """
    Create a subplot with multiple metrics for comparison
    
    Parameters:
    -----------
    metrics_dict : dict
        Dictionary with model names as keys and metric dictionaries as values
    metrics_to_plot : list
        List of metric names to plot (default: MSE, RMSE, MAE, R2)
        
    Returns:
    --------
    plotly.graph_objects.Figure
        The plotly figure object
    """
    if metrics_to_plot is None:
        metrics_to_plot = ['MSE', 'RMSE', 'MAE', 'R2']
    
    # Create subplots
    fig = make_subplots(
        rows=len(metrics_to_plot),
        cols=1,
        subplot_titles=[f'Model Comparison - {metric}' for metric in metrics_to_plot],
        vertical_spacing=0.1
    )
    
    # For each metric
    for i, metric in enumerate(metrics_to_plot):
        # Prepare data
        models = []
        values = []
        
        for model_name, metrics in metrics_dict.items():
            if metric in metrics:
                models.append(model_name)
                values.append(metrics[metric])
        
        # Create bar trace
        bar = go.Bar(
            x=models,
            y=values,
            name=metric,
            marker_color=px.colors.qualitative.Plotly[i % len(px.colors.qualitative.Plotly)]
        )
        
        # Add trace to subplot
        fig.add_trace(bar, row=i+1, col=1)
        
        # Update y-axis title
        fig.update_yaxes(title_text=metric, row=i+1, col=1)
    
    # Update x-axis title for the last subplot
    fig.update_xaxes(title_text="Model", row=len(metrics_to_plot), col=1)
    
    # Update layout
    fig.update_layout(
        height=250 * len(metrics_to_plot),
        showlegend=False,
        title_text="Model Performance Metrics"
    )
    
    return fig

def plot_correlation_matrix(data, title="Feature Correlation Matrix"):
    """
    Create a heatmap of feature correlations
    
    Parameters:
    -----------
    data : pandas DataFrame
        The data containing features
    title : str
        The title of the plot
        
    Returns:
    --------
    plotly.graph_objects.Figure
        The plotly figure object
    """
    # Calculate correlation matrix
    corr_matrix = data.corr(numeric_only=True)
    
    # Create heatmap
    fig = px.imshow(
        corr_matrix,
        text_auto=True,
        aspect="auto",
        color_continuous_scale='RdBu_r',
        title=title
    )
    
    fig.update_layout(
        height=600,
        width=700
    )
    
    return fig

def plot_seasonal_decomposition(decomposition, title="Seasonal Decomposition"):
    """
    Create a plot of seasonal decomposition
    
    Parameters:
    -----------
    decomposition : statsmodels.tsa.seasonal.DecomposeResult
        The seasonal decomposition result
    title : str
        The title of the plot
        
    Returns:
    --------
    plotly.graph_objects.Figure
        The plotly figure object
    """
    # Create subplots
    fig = make_subplots(
        rows=4,
        cols=1,
        subplot_titles=["Observed", "Trend", "Seasonal", "Residual"],
        vertical_spacing=0.1
    )
    
    # Add observed data
    fig.add_trace(
        go.Scatter(x=decomposition.observed.index, y=decomposition.observed, mode='lines', name='Observed'),
        row=1, col=1
    )
    
    # Add trend
    fig.add_trace(
        go.Scatter(x=decomposition.trend.index, y=decomposition.trend, mode='lines', name='Trend'),
        row=2, col=1
    )
    
    # Add seasonal
    fig.add_trace(
        go.Scatter(x=decomposition.seasonal.index, y=decomposition.seasonal, mode='lines', name='Seasonal'),
        row=3, col=1
    )
    
    # Add residual
    fig.add_trace(
        go.Scatter(x=decomposition.resid.index, y=decomposition.resid, mode='lines', name='Residual'),
        row=4, col=1
    )
    
    # Update layout
    fig.update_layout(
        height=800,
        title_text=title,
        showlegend=False
    )
    
    return fig
