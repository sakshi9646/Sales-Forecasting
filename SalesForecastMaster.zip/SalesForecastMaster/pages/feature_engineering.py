import streamlit as st
import pandas as pd
import numpy as np
from utils.data_processor import DataProcessor
from utils.visualization import plot_correlation_matrix, plot_time_series
import plotly.express as px

def render_feature_engineering():
    st.header("Feature Engineering")
    
    # Check if data is uploaded
    if st.session_state.data is None:
        st.warning("Please upload your data first in the Data Upload page.")
        return
    
    # Display data info
    st.subheader("Dataset Information")
    data = st.session_state.data
    st.write(f"Shape: {data.shape}")
    
    # Show columns and data types
    col_info = pd.DataFrame({
        'Column': data.columns,
        'Data Type': data.dtypes,
        'Missing Values': data.isnull().sum().values,
        'Missing %': (data.isnull().sum().values / len(data) * 100).round(2)
    })
    st.dataframe(col_info)
    
    # Column selection
    st.subheader("Select Features")
    
    if st.session_state.target_column:
        target_col = st.session_state.target_column
        st.info(f"Target column: {target_col}")
        
        # Get all columns except target
        all_features = [col for col in data.columns if col != target_col]
        
        # Select features for model training
        st.markdown("**Select features to include in your model:**")
        feature_cols = st.multiselect(
            "Features",
            options=all_features,
            default=st.session_state.selected_features if 'selected_features' in st.session_state else all_features[:5]
        )
        
        # Update session state
        st.session_state.selected_features = feature_cols
        
        # Show feature correlation
        if st.checkbox("Show feature correlation matrix"):
            # Only include numeric columns for correlation
            numeric_cols = [col for col in feature_cols + [target_col] if data[col].dtype in ['int64', 'float64']]
            if len(numeric_cols) > 1:
                corr_fig = plot_correlation_matrix(data[numeric_cols], title="Feature Correlation Matrix")
                st.plotly_chart(corr_fig, use_container_width=True)
            else:
                st.warning("Need at least 2 numeric columns to calculate correlations.")
    
    # Feature Engineering Options
    st.subheader("Feature Engineering Options")
    
    # Initialize data processor
    data_processor = DataProcessor()
    
    # Check if date column is available
    date_cols = [col for col in data.columns if data[col].dtype == 'datetime64[ns]' or 'date' in col.lower()]
    
    if date_cols:
        st.markdown("**Time-based Feature Engineering:**")
        
        # Select date column
        date_col = st.selectbox(
            "Select date column",
            options=date_cols,
            index=0
        )
        
        # Time features options
        time_features = st.multiselect(
            "Select time features to extract",
            options=["Year", "Month", "Day", "Day of Week", "Quarter", "Is Month Start/End", "Is Quarter Start/End", "Season"],
            default=["Month", "Day of Week", "Season"]
        )
        
        # Lag features
        st.markdown("**Lag Features:**")
        use_lag = st.checkbox("Add lag features", value=True)
        
        if use_lag and st.session_state.target_column:
            lag_values = st.multiselect(
                "Select lag periods",
                options=[1, 3, 7, 14, 28, 30],
                default=[1, 7]
            )
        
        # Rolling window features
        st.markdown("**Rolling Window Features:**")
        use_rolling = st.checkbox("Add rolling window features", value=True)
        
        if use_rolling and st.session_state.target_column:
            window_sizes = st.multiselect(
                "Select window sizes",
                options=[3, 7, 14, 30],
                default=[7]
            )
            
            window_functions = st.multiselect(
                "Select window functions",
                options=["Mean", "Std", "Min", "Max"],
                default=["Mean"]
            )
    
    # Categorical feature handling
    st.markdown("**Categorical Feature Handling:**")
    
    # Identify categorical columns
    cat_cols = [col for col in data.columns if data[col].dtype == 'object' or data[col].dtype.name == 'category']
    
    if cat_cols:
        encoding_method = st.radio(
            "Select encoding method for categorical features",
            options=["One-Hot Encoding", "Label Encoding"],
            index=0
        )
        
        st.markdown("**Categorical columns detected:**")
        st.write(", ".join(cat_cols))
    else:
        st.write("No categorical features detected.")
    
    # Apply feature engineering
    if st.button("Apply Feature Engineering"):
        try:
            # Start with a copy of the data
            engineered_data = data.copy()
            
            # 1. Process date features if selected
            if date_cols and time_features:
                # Make sure date column is datetime
                if engineered_data[date_col].dtype != 'datetime64[ns]':
                    engineered_data[date_col] = pd.to_datetime(engineered_data[date_col])
                
                # Extract selected time features
                if "Year" in time_features:
                    engineered_data['year'] = engineered_data[date_col].dt.year
                
                if "Month" in time_features:
                    engineered_data['month'] = engineered_data[date_col].dt.month
                
                if "Day" in time_features:
                    engineered_data['day'] = engineered_data[date_col].dt.day
                
                if "Day of Week" in time_features:
                    engineered_data['day_of_week'] = engineered_data[date_col].dt.dayofweek
                
                if "Quarter" in time_features:
                    engineered_data['quarter'] = engineered_data[date_col].dt.quarter
                
                if "Is Month Start/End" in time_features:
                    engineered_data['is_month_start'] = engineered_data[date_col].dt.is_month_start.astype(int)
                    engineered_data['is_month_end'] = engineered_data[date_col].dt.is_month_end.astype(int)
                
                if "Is Quarter Start/End" in time_features:
                    engineered_data['is_quarter_start'] = engineered_data[date_col].dt.is_quarter_start.astype(int)
                    engineered_data['is_quarter_end'] = engineered_data[date_col].dt.is_quarter_end.astype(int)
                
                if "Season" in time_features:
                    # Add seasons based on month
                    seasons = {
                        1: 'Winter', 2: 'Winter', 3: 'Spring',
                        4: 'Spring', 5: 'Spring', 6: 'Summer',
                        7: 'Summer', 8: 'Summer', 9: 'Fall',
                        10: 'Fall', 11: 'Fall', 12: 'Winter'
                    }
                    engineered_data['season'] = engineered_data[date_col].dt.month.map(seasons)
            
            # 2. Add lag features if selected
            target_col = st.session_state.target_column
            if use_lag and target_col and lag_values:
                for lag in lag_values:
                    engineered_data[f'{target_col}_lag_{lag}'] = engineered_data[target_col].shift(lag)
            
            # 3. Add rolling window features if selected
            if use_rolling and target_col and window_sizes and window_functions:
                for window in window_sizes:
                    if "Mean" in window_functions:
                        engineered_data[f'{target_col}_rolling_mean_{window}'] = engineered_data[target_col].rolling(window=window).mean()
                    if "Std" in window_functions:
                        engineered_data[f'{target_col}_rolling_std_{window}'] = engineered_data[target_col].rolling(window=window).std()
                    if "Min" in window_functions:
                        engineered_data[f'{target_col}_rolling_min_{window}'] = engineered_data[target_col].rolling(window=window).min()
                    if "Max" in window_functions:
                        engineered_data[f'{target_col}_rolling_max_{window}'] = engineered_data[target_col].rolling(window=window).max()
            
            # 4. Handle categorical features
            if cat_cols and encoding_method:
                if encoding_method == "One-Hot Encoding":
                    engineered_data = pd.get_dummies(engineered_data, columns=cat_cols, drop_first=True)
                else:  # Label Encoding
                    from sklearn.preprocessing import LabelEncoder
                    encoder = LabelEncoder()
                    for col in cat_cols:
                        engineered_data[col] = encoder.fit_transform(engineered_data[col].astype(str))
            
            # 5. Handle missing values created by lag or rolling features
            engineered_data = engineered_data.dropna()
            
            # Update session state
            st.session_state.data = engineered_data
            
            # Display the results
            st.success(f"Feature engineering applied successfully! New shape: {engineered_data.shape}")
            
            # Show preview of the engineered data
            st.subheader("Preview of Engineered Data")
            st.dataframe(engineered_data.head())
            
            # Show statistics of the new features
            st.subheader("New Feature Statistics")
            # Only show statistics for numeric columns
            numeric_cols = engineered_data.select_dtypes(include=['float64', 'int64']).columns
            st.dataframe(engineered_data[numeric_cols].describe())
            
            # Update selected features to include new engineered features
            new_features = [col for col in engineered_data.columns if col not in data.columns and col != target_col]
            st.session_state.selected_features.extend(new_features)
            
            # Show information about new features
            if new_features:
                st.subheader("New Features Created")
                st.write(", ".join(new_features))
                
        except Exception as e:
            st.error(f"Error during feature engineering: {e}")
    
    # Data visualization section
    st.subheader("Data Visualization")
    
    if st.session_state.target_column:
        target_col = st.session_state.target_column
        
        # Time series plot if date column is available
        if date_cols:
            date_col_for_plot = st.selectbox(
                "Select date column for time series plot",
                options=date_cols,
                index=0
            )
            
            # Create and display time series plot
            ts_fig = plot_time_series(
                data, 
                date_col_for_plot, 
                target_col, 
                title=f"Time Series: {target_col} over time"
            )
            st.plotly_chart(ts_fig, use_container_width=True)
        
        # Feature distribution plots
        st.markdown("**Feature Distributions:**")
        
        if 'selected_features' in st.session_state and st.session_state.selected_features:
            feature_to_plot = st.selectbox(
                "Select a feature to visualize distribution",
                options=st.session_state.selected_features
            )
            
            if feature_to_plot:
                # Show histogram
                hist_fig = px.histogram(
                    data, 
                    x=feature_to_plot,
                    title=f"Distribution of {feature_to_plot}"
                )
                st.plotly_chart(hist_fig, use_container_width=True)
                
                # Show box plot
                box_fig = px.box(
                    data, 
                    y=feature_to_plot,
                    title=f"Box Plot of {feature_to_plot}"
                )
                st.plotly_chart(box_fig, use_container_width=True)
                
                # Show scatter plot against target
                if data[feature_to_plot].dtype in ['int64', 'float64']:
                    scatter_fig = px.scatter(
                        data,
                        x=feature_to_plot,
                        y=target_col,
                        title=f"{feature_to_plot} vs {target_col}",
                        trendline="ols"
                    )
                    st.plotly_chart(scatter_fig, use_container_width=True)
        
    st.markdown("---")
    st.info("Once you're happy with your features, proceed to the Model Training page to build and evaluate forecasting models.")
