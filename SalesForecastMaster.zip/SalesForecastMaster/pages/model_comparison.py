import streamlit as st
import pandas as pd
import numpy as np
from utils.visualization import plot_model_comparison, plot_multiple_metrics, plot_actual_vs_predicted
import plotly.express as px

def render_model_comparison():
    st.header("Model Comparison")
    
    # Check if any models have been trained
    if 'metrics' not in st.session_state or not st.session_state.metrics:
        st.warning("No models have been trained yet. Please go to the Model Training page first.")
        return
    
    # Display overall comparison
    st.subheader("Model Performance Comparison")
    
    # Get available metrics
    available_metrics = []
    for model_name, metrics in st.session_state.metrics.items():
        for metric_name in metrics.keys():
            if metric_name not in available_metrics:
                available_metrics.append(metric_name)
    
    # Let user select metric for comparison
    selected_metric = st.selectbox(
        "Select metric for comparison",
        options=available_metrics,
        index=available_metrics.index('RMSE') if 'RMSE' in available_metrics else 0
    )
    
    # Create comparison chart
    fig = plot_model_comparison(st.session_state.metrics, selected_metric)
    st.plotly_chart(fig, use_container_width=True)
    
    # Show multiple metrics comparison
    st.subheader("Multiple Metrics Comparison")
    metrics_to_plot = st.multiselect(
        "Select metrics to compare",
        options=available_metrics,
        default=['MSE', 'RMSE', 'MAE'] if all(m in available_metrics for m in ['MSE', 'RMSE', 'MAE']) else available_metrics[:3]
    )
    
    if metrics_to_plot:
        multi_fig = plot_multiple_metrics(st.session_state.metrics, metrics_to_plot)
        st.plotly_chart(multi_fig, use_container_width=True)
    
    # Display metrics table
    st.subheader("Model Metrics Table")
    
    # Create a table with all metrics for all models
    metrics_data = []
    for model_name, metrics in st.session_state.metrics.items():
        model_metrics = {'Model': model_name}
        for metric_name, value in metrics.items():
            model_metrics[metric_name] = round(value, 4)
        metrics_data.append(model_metrics)
    
    metrics_df = pd.DataFrame(metrics_data)
    st.dataframe(metrics_df)
    
    # Display model predictions
    st.subheader("Model Predictions Comparison")
    
    # Get available models
    available_models = list(st.session_state.predictions.keys())
    
    # Let user select models to compare
    models_to_compare = st.multiselect(
        "Select models to compare",
        options=available_models,
        default=available_models[:2] if len(available_models) >= 2 else available_models
    )
    
    if models_to_compare:
        # Create figure for comparison
        import plotly.graph_objects as go
        
        fig = go.Figure()
        
        # Add actual values (only once)
        first_model = models_to_compare[0]
        y_true = st.session_state.predictions[first_model]['y_true']
        fig.add_trace(go.Scatter(
            y=y_true,
            mode='lines',
            name='Actual',
            line=dict(color='black', width=2)
        ))
        
        # Add predicted values for each model
        for model_name in models_to_compare:
            pred_data = st.session_state.predictions[model_name]
            fig.add_trace(go.Scatter(
                y=pred_data['y_pred'],
                mode='lines',
                name=f'{model_name} Predicted',
                line=dict(dash='dash')
            ))
        
        # Update layout
        fig.update_layout(
            title="Actual vs Predicted Values for Multiple Models",
            xaxis_title="Index",
            yaxis_title="Value",
            legend=dict(x=0.01, y=0.99),
            hovermode="x unified"
        )
        
        st.plotly_chart(fig, use_container_width=True)
    
    # Display residual analysis
    st.subheader("Residual Analysis")
    
    # Let user select model for residual analysis
    residual_model = st.selectbox(
        "Select model for residual analysis",
        options=available_models
    )
    
    if residual_model:
        pred_data = st.session_state.predictions[residual_model]
        y_true = pred_data['y_true']
        y_pred = pred_data['y_pred']
        
        # Calculate residuals
        residuals = y_true - y_pred
        
        # Create residual plots
        col1, col2 = st.columns(2)
        
        with col1:
            # Residual histogram
            hist_fig = px.histogram(
                residuals,
                title=f"{residual_model} - Residual Distribution",
                labels={'value': 'Residual'},
                marginal="box"
            )
            st.plotly_chart(hist_fig, use_container_width=True)
        
        with col2:
            # Residual scatter plot
            scatter_fig = px.scatter(
                x=y_pred,
                y=residuals,
                title=f"{residual_model} - Residuals vs Predicted",
                labels={'x': 'Predicted', 'y': 'Residual'}
            )
            # Add horizontal line at y=0
            scatter_fig.add_hline(y=0, line_dash="dash", line_color="red")
            st.plotly_chart(scatter_fig, use_container_width=True)
        
        # Additional residual statistics
        st.subheader("Residual Statistics")
        residual_stats = pd.DataFrame({
            'Statistic': ['Mean', 'Std Dev', 'Min', 'Max', 'Q1 (25%)', 'Median', 'Q3 (75%)'],
            'Value': [
                np.mean(residuals).round(4),
                np.std(residuals).round(4),
                np.min(residuals).round(4),
                np.max(residuals).round(4),
                np.percentile(residuals, 25).round(4),
                np.percentile(residuals, 50).round(4),
                np.percentile(residuals, 75).round(4)
            ]
        })
        st.table(residual_stats)
    
    # Model selection recommendation
    st.subheader("Model Recommendation")
    
    # Create a simple scoring system
    model_scores = {}
    
    for model_name, metrics in st.session_state.metrics.items():
        # Lower RMSE, MSE, MAE is better; Higher R2 is better
        if 'RMSE' in metrics and 'R2' in metrics:
            # Invert RMSE so that higher is better, then normalize
            rmse_values = [m['RMSE'] for m in st.session_state.metrics.values()]
            max_rmse = max(rmse_values)
            min_rmse = min(rmse_values)
            rmse_range = max_rmse - min_rmse
            
            if rmse_range == 0:  # Avoid division by zero
                rmse_score = 1.0
            else:
                rmse_score = 1 - ((metrics['RMSE'] - min_rmse) / rmse_range)
            
            # R2 is already scaled where higher is better
            r2_score = metrics['R2']
            
            # Combined score (equal weight)
            model_scores[model_name] = (rmse_score + r2_score) / 2
    
    if model_scores:
        # Find the best model
        best_model = max(model_scores, key=model_scores.get)
        
        # Display recommendation
        st.success(f"Recommended Model: **{best_model}**")
        st.write(f"Overall Score: {model_scores[best_model]:.4f}")
        
        # Show why this model was recommended
        st.markdown("### Why this model was recommended:")
        
        best_metrics = st.session_state.metrics[best_model]
        metrics_explanation = [
            f"- **RMSE**: {best_metrics['RMSE']:.4f} - {'lowest' if best_metrics['RMSE'] == min(m['RMSE'] for m in st.session_state.metrics.values()) else 'good'} prediction error",
            f"- **R²**: {best_metrics['R2']:.4f} - {'highest' if best_metrics['R2'] == max(m['R2'] for m in st.session_state.metrics.values()) else 'good'} explained variance",
        ]
        
        for explanation in metrics_explanation:
            st.markdown(explanation)
        
        # Display additional considerations
        st.markdown("### Additional Considerations:")
        st.markdown("""
        When selecting a model, also consider:
        - Model complexity and interpretability
        - Training and prediction speed
        - Ability to handle outliers and missing data
        - Specific requirements of your forecasting task
        """)
    
    # Export options
    st.subheader("Export Results")
    
    # Export metrics
    if st.button("Export Metrics as CSV"):
        # Convert metrics to CSV
        csv = metrics_df.to_csv(index=False)
        
        # Create download button
        st.download_button(
            label="Download Metrics CSV",
            data=csv,
            file_name="model_metrics.csv",
            mime="text/csv"
        )
    
    st.markdown("---")
    st.info("This comparison helps you select the best model for your sales forecasting needs. Consider both the quantitative metrics and qualitative factors when making your decision.")
