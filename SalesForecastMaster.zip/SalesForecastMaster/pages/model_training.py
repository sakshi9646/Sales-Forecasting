import streamlit as st
import pandas as pd
import numpy as np
from utils.data_processor import DataProcessor
from utils.model_trainer import ModelTrainer
from utils.visualization import plot_feature_importance, plot_actual_vs_predicted, plot_forecast_with_confidence
import plotly.express as px
from sklearn.model_selection import train_test_split

def render_model_training():
    st.header("Model Training")
    
    # Check if data is uploaded
    if st.session_state.data is None:
        st.warning("Please upload your data first in the Data Upload page.")
        return
    
    # Initialize data processor and model trainer
    data_processor = DataProcessor()
    model_trainer = ModelTrainer()
    
    # Display data info
    st.subheader("Dataset Information")
    data = st.session_state.data
    target_col = st.session_state.target_column
    
    if not target_col:
        st.warning("Target column not selected. Please go back to the Data Upload page.")
        return
    
    st.write(f"Shape: {data.shape}")
    st.write(f"Target Column: {target_col}")
    
    # Feature selection
    st.subheader("Feature Selection")
    
    # Get available features (all columns except the target)
    available_features = [col for col in data.columns if col != target_col]
    
    # Let user select features for the model
    selected_features = st.multiselect(
        "Select features to include in your model",
        options=available_features,
        default=st.session_state.selected_features if 'selected_features' in st.session_state else available_features[:5]
    )
    
    # Model selection
    st.subheader("Model Selection")
    
    # Create tabs for different model types
    model_tabs = st.tabs(["Linear Models", "Tree-based Models", "Time Series Models", "Deep Learning"])
    
    # Define model parameters
    model_params = {}
    selected_models = []
    
    # Linear Models tab
    with model_tabs[0]:
        st.markdown("### Linear Models")
        
        # Linear Regression
        if st.checkbox("Linear Regression", value=True):
            selected_models.append("Linear Regression")
            model_params["Linear Regression"] = {}
            
            # No special parameters needed for basic linear regression
            st.success("Linear Regression selected")
    
    # Tree-based Models tab
    with model_tabs[1]:
        st.markdown("### Tree-based Models")
        
        # Random Forest
        if st.checkbox("Random Forest", value=True):
            selected_models.append("Random Forest")
            
            # Random Forest parameters
            rf_col1, rf_col2 = st.columns(2)
            with rf_col1:
                n_estimators = st.slider("Number of Trees", min_value=10, max_value=500, value=100, step=10)
            with rf_col2:
                max_depth = st.slider("Maximum Depth", min_value=1, max_value=50, value=10, step=1)
            
            model_params["Random Forest"] = {
                "n_estimators": n_estimators,
                "max_depth": max_depth
            }
            
            st.success("Random Forest selected")
        
        # XGBoost
        if st.checkbox("XGBoost", value=True):
            selected_models.append("XGBoost")
            
            # XGBoost parameters
            xgb_col1, xgb_col2, xgb_col3 = st.columns(3)
            with xgb_col1:
                xgb_n_estimators = st.slider("XGB Trees", min_value=10, max_value=500, value=100, step=10)
            with xgb_col2:
                learning_rate = st.slider("Learning Rate", min_value=0.01, max_value=0.3, value=0.1, step=0.01)
            with xgb_col3:
                xgb_max_depth = st.slider("XGB Max Depth", min_value=1, max_value=15, value=6, step=1)
            
            model_params["XGBoost"] = {
                "n_estimators": xgb_n_estimators,
                "learning_rate": learning_rate,
                "max_depth": xgb_max_depth
            }
            
            st.success("XGBoost selected")
    
    # Time Series Models tab
    with model_tabs[2]:
        st.markdown("### Time Series Models")
        
        # Prophet
        if st.checkbox("Prophet", value=True):
            selected_models.append("Prophet")
            
            # Prophet parameters
            prophet_col1, prophet_col2 = st.columns(2)
            with prophet_col1:
                seasonality_mode = st.selectbox(
                    "Seasonality Mode",
                    options=["additive", "multiplicative"],
                    index=0
                )
            with prophet_col2:
                yearly_seasonality = st.checkbox("Yearly Seasonality", value=True)
                weekly_seasonality = st.checkbox("Weekly Seasonality", value=True)
            
            model_params["Prophet"] = {
                "seasonality_mode": seasonality_mode,
                "yearly_seasonality": yearly_seasonality,
                "weekly_seasonality": weekly_seasonality
            }
            
            # Date column for Prophet
            date_cols = [col for col in data.columns if 'date' in col.lower() or 'time' in col.lower() 
                          or data[col].dtype == 'datetime64[ns]']
            
            if date_cols:
                prophet_date_col = st.selectbox(
                    "Select date column for Prophet",
                    options=date_cols,
                    index=0
                )
                model_params["Prophet"]["date_column"] = prophet_date_col
            else:
                st.warning("No date column found for Prophet. Please add a date column in Feature Engineering.")
                
            st.success("Prophet selected")
    
    # Deep Learning tab
    with model_tabs[3]:
        st.markdown("### Deep Learning Models")
        
        # Check if TensorFlow is available
        try:
            from utils.model_trainer import TENSORFLOW_AVAILABLE
            tensorflow_status = TENSORFLOW_AVAILABLE
        except ImportError:
            tensorflow_status = False
        
        # LSTM
        if tensorflow_status:
            if st.checkbox("LSTM", value=True):
                selected_models.append("LSTM")
                
                # LSTM parameters
                lstm_col1, lstm_col2 = st.columns(2)
                with lstm_col1:
                    epochs = st.slider("Epochs", min_value=10, max_value=200, value=50, step=10)
                with lstm_col2:
                    batch_size = st.slider("Batch Size", min_value=8, max_value=128, value=32, step=8)
                
                sequence_length = st.slider("Sequence Length", min_value=5, max_value=100, value=30, step=5)
                
                model_params["LSTM"] = {
                    "epochs": epochs,
                    "batch_size": batch_size,
                    "sequence_length": sequence_length
                }
                
                st.success("LSTM selected")
        else:
            st.warning("TensorFlow is not available. LSTM model cannot be used. Other models are still available for training.")
    
    # Train-test split settings
    st.subheader("Train-Test Split")
    
    test_size = st.slider("Test Set Size (%)", min_value=10, max_value=50, value=20, step=5) / 100
    
    # Training section
    st.subheader("Model Training")
    
    if st.button("Train Models"):
        if not selected_features:
            st.error("Please select at least one feature for training.")
        elif not selected_models:
            st.error("Please select at least one model for training.")
        else:
            try:
                # Prepare data
                X = data[selected_features]
                y = data[target_col]
                
                # Train-test split
                X_train, X_test, y_train, y_test = train_test_split(
                    X, y, test_size=test_size, random_state=42
                )
                
                # Display split information
                st.write(f"Training set: {X_train.shape[0]} samples")
                st.write(f"Testing set: {X_test.shape[0]} samples")
                
                # Progress bar
                progress_bar = st.progress(0)
                
                # Train models
                for i, model_name in enumerate(selected_models):
                    # Update progress
                    progress = (i / len(selected_models)) * 100
                    progress_bar.progress(int(progress))
                    
                    # Display training message
                    st.write(f"Training {model_name}...")
                    
                    if model_name == "Linear Regression":
                        model = model_trainer.train_linear_regression(X_train.values, y_train.values)
                        metrics = model_trainer.evaluate_model(model_name, X_test.values, y_test.values)
                        
                        # Get feature importance
                        importance_df = model_trainer.get_feature_importance(model_name, selected_features)
                        
                        # Get predictions for plotting
                        y_pred = model.predict(X_test.values)
                        
                        # Store in session state
                        if 'predictions' not in st.session_state:
                            st.session_state.predictions = {}
                        st.session_state.predictions[model_name] = {
                            'y_true': y_test.values,
                            'y_pred': y_pred
                        }
                        
                    elif model_name == "Random Forest":
                        params = model_params[model_name]
                        model = model_trainer.train_random_forest(
                            X_train.values, 
                            y_train.values,
                            n_estimators=params["n_estimators"],
                            max_depth=params["max_depth"]
                        )
                        metrics = model_trainer.evaluate_model(model_name, X_test.values, y_test.values)
                        
                        # Get feature importance
                        importance_df = model_trainer.get_feature_importance(model_name, selected_features)
                        
                        # Get predictions for plotting
                        y_pred = model.predict(X_test.values)
                        
                        # Store in session state
                        if 'predictions' not in st.session_state:
                            st.session_state.predictions = {}
                        st.session_state.predictions[model_name] = {
                            'y_true': y_test.values,
                            'y_pred': y_pred
                        }
                        
                    elif model_name == "XGBoost":
                        params = model_params[model_name]
                        model = model_trainer.train_xgboost(
                            X_train.values, 
                            y_train.values,
                            n_estimators=params["n_estimators"],
                            learning_rate=params["learning_rate"],
                            max_depth=params["max_depth"]
                        )
                        metrics = model_trainer.evaluate_model(model_name, X_test.values, y_test.values)
                        
                        # Get feature importance
                        importance_df = model_trainer.get_feature_importance(model_name, selected_features)
                        
                        # Get predictions for plotting
                        y_pred = model.predict(X_test.values)
                        
                        # Store in session state
                        if 'predictions' not in st.session_state:
                            st.session_state.predictions = {}
                        st.session_state.predictions[model_name] = {
                            'y_true': y_test.values,
                            'y_pred': y_pred
                        }
                        
                    elif model_name == "Prophet":
                        if "date_column" in model_params[model_name]:
                            params = model_params[model_name]
                            date_col = params["date_column"]
                            
                            # Prepare data for Prophet
                            prophet_data = data_processor.prepare_for_prophet(
                                data.reset_index(), 
                                date_col, 
                                target_col
                            )
                            
                            # Split into train and test
                            split_idx = int(len(prophet_data) * (1 - test_size))
                            prophet_train = prophet_data.iloc[:split_idx]
                            prophet_test = prophet_data.iloc[split_idx:]
                            
                            # Train Prophet model
                            model = model_trainer.train_prophet(
                                prophet_train,
                                seasonality_mode=params["seasonality_mode"],
                                yearly_seasonality=params["yearly_seasonality"],
                                weekly_seasonality=params["weekly_seasonality"]
                            )
                            
                            # Evaluate Prophet model
                            metrics, forecast = model_trainer.evaluate_prophet(model, prophet_test)
                            
                            # Store forecast for later visualization
                            if 'prophet_forecast' not in st.session_state:
                                st.session_state.prophet_forecast = {}
                            st.session_state.prophet_forecast[model_name] = forecast
                            
                            # Store in session state
                            if 'predictions' not in st.session_state:
                                st.session_state.predictions = {}
                            st.session_state.predictions[model_name] = {
                                'y_true': prophet_test['y'].values,
                                'y_pred': forecast.loc[forecast['ds'].isin(prophet_test['ds']), 'yhat'].values
                            }
                        else:
                            st.error(f"Date column not specified for Prophet. Skipping.")
                            continue
                            
                    elif model_name == "LSTM":
                        # Check if TensorFlow is available
                        try:
                            from utils.model_trainer import TENSORFLOW_AVAILABLE
                            tensorflow_status = TENSORFLOW_AVAILABLE
                        except ImportError:
                            tensorflow_status = False
                            
                        if not tensorflow_status:
                            st.warning("TensorFlow is not available. Skipping LSTM model.")
                            continue
                            
                        params = model_params[model_name]
                        
                        # Prepare data for LSTM
                        sequence_length = params["sequence_length"]
                        X_lstm, y_lstm = data_processor.prepare_for_lstm(data, target_col, sequence_length)
                        
                        # Split into train and test
                        split_idx = int(len(X_lstm) * (1 - test_size))
                        X_lstm_train, X_lstm_test = X_lstm[:split_idx], X_lstm[split_idx:]
                        y_lstm_train, y_lstm_test = y_lstm[:split_idx], y_lstm[split_idx:]
                        
                        # Train LSTM model
                        model = model_trainer.train_lstm(
                            X_lstm_train, 
                            y_lstm_train,
                            epochs=params["epochs"],
                            batch_size=params["batch_size"]
                        )
                        
                        # Check if model was trained successfully
                        if model is None:
                            st.warning("LSTM model could not be trained. Skipping evaluation.")
                            continue
                            
                        # Evaluate LSTM model
                        metrics = model_trainer.evaluate_lstm(model, X_lstm_test, y_lstm_test)
                        
                        # Check if metrics were calculated
                        if metrics is None:
                            st.warning("LSTM model could not be evaluated. Skipping visualization.")
                            continue
                            
                        # Store in session state
                        if 'predictions' not in st.session_state:
                            st.session_state.predictions = {}
                        st.session_state.predictions[model_name] = {
                            'y_true': y_lstm_test,
                            'y_pred': model.predict(X_lstm_test).flatten()
                        }
                    
                    # Store and display metrics if available
                    if metrics is not None:
                        if 'metrics' not in st.session_state:
                            st.session_state.metrics = {}
                        st.session_state.metrics[model_name] = metrics
                        
                        # Display metrics
                        st.subheader(f"{model_name} Performance")
                        metrics_df = pd.DataFrame({
                            'Metric': list(metrics.keys()),
                            'Value': list(metrics.values())
                        })
                        st.table(metrics_df)
                    else:
                        st.warning(f"No metrics available for {model_name} model.")
                    
                    # Plot actual vs predicted if predictions are available
                    if (model_name in st.session_state.predictions and 
                        'y_true' in st.session_state.predictions[model_name] and 
                        'y_pred' in st.session_state.predictions[model_name]):
                        try:
                            pred_data = st.session_state.predictions[model_name]
                            fig = plot_actual_vs_predicted(
                                pred_data['y_true'],
                                pred_data['y_pred'],
                                title=f"{model_name}: Actual vs Predicted"
                            )
                            st.plotly_chart(fig, use_container_width=True)
                        except Exception as e:
                            st.warning(f"Could not create plot for {model_name}: {e}")
                    
                    # Show feature importance if available
                    if model_name in ["Linear Regression", "Random Forest", "XGBoost"]:
                        if model_trainer.feature_importance.get(model_name) is not None:
                            st.subheader(f"{model_name} Feature Importance")
                            fig = plot_feature_importance(
                                model_trainer.feature_importance[model_name],
                                title=f"{model_name} Feature Importance"
                            )
                            st.plotly_chart(fig, use_container_width=True)
                    
                    # Show Prophet forecast if available
                    if model_name == "Prophet" and 'prophet_forecast' in st.session_state:
                        st.subheader("Prophet Forecast with Confidence Intervals")
                        forecast = st.session_state.prophet_forecast[model_name]
                        fig = plot_forecast_with_confidence(
                            forecast,
                            title="Prophet Forecast with 95% Confidence Intervals"
                        )
                        st.plotly_chart(fig, use_container_width=True)
                
                # Complete progress bar
                progress_bar.progress(100)
                
                # Store models in session state
                st.session_state.models = model_trainer.models
                
                st.success("Training complete! You can now compare models in the Model Comparison page.")
                
            except Exception as e:
                st.error(f"Error during model training: {e}")
    
    # Generate forecasts if models are trained
    st.subheader("Generate Forecasts")
    
    if 'models' in st.session_state and st.session_state.models:
        # Check if any models are trained
        trained_models = [name for name, model in st.session_state.models.items() if model is not None]
        
        if not trained_models:
            st.warning("No trained models available. Please train at least one model first.")
        else:
            # Let user select model for forecasting
            forecast_model = st.selectbox(
                "Select model for forecasting",
                options=trained_models
            )
            
            # Forecast horizon
            forecast_horizon = st.slider(
                "Forecast Horizon (periods)",
                min_value=1,
                max_value=365,
                value=30
            )
            
            if st.button("Generate Forecast"):
                # Generate forecast based on model type
                if forecast_model == "Prophet" and 'prophet_forecast' in st.session_state:
                    # Prophet forecast already generated, just show it
                    st.subheader(f"{forecast_model} Forecast")
                    forecast = st.session_state.prophet_forecast[forecast_model]
                    
                    # Limit to future periods
                    future_forecast = forecast[forecast['ds'] > data.index.max()][:forecast_horizon]
                    
                    # Display forecast as table
                    st.write("Future Forecast:")
                    forecast_df = pd.DataFrame({
                        'Date': future_forecast['ds'],
                        'Forecast': future_forecast['yhat'].round(2),
                        'Lower Bound': future_forecast['yhat_lower'].round(2),
                        'Upper Bound': future_forecast['yhat_upper'].round(2)
                    })
                    st.dataframe(forecast_df)
                    
                    # Plot forecast
                    fig = plot_forecast_with_confidence(
                        forecast,
                        title=f"{forecast_model} Forecast for Next {forecast_horizon} Periods"
                    )
                    st.plotly_chart(fig, use_container_width=True)
                    
                elif forecast_model == "LSTM":
                    st.warning("LSTM forecasting requires time series sequences. This is a simplified implementation.")
                    st.info("For full LSTM forecasting capabilities, consider the recursive forecasting approach.")
                    
                else:
                    st.warning(f"Forecasting for {forecast_model} is not implemented in this simple demo.")
                    st.info("For a production application, custom forecasting logic would be implemented.")
    else:
        st.warning("No trained models available. Please train at least one model first.")
